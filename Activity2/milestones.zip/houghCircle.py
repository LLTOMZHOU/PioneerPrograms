import numpy as np
import cv2

#Since the coins pictures provided all have some certain
origImg = cv2.imread("coins7.jpg")

grayImg = cv2.cvtColor(origImg, cv2.COLOR_BGR2GRAY)

thres, threshImg1 = cv2.threshold(grayImg, 97, 255, cv2.THRESH_BINARY_INV)
thres, threshImg2 = cv2.threshold(grayImg, 200, 255, cv2.THRESH_BINARY)

binaryImg = cv2.bitwise_or(threshImg1, threshImg2)

# binaryImg = cv2.cvtColor(binaryImg, cv2.COLOR_BGR2GRAY)
st = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (4,4))
binaryImg = cv2.morphologyEx(binaryImg, cv2.MORPH_DILATE, st)
st = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (4,4))
binaryImg = cv2.morphologyEx(binaryImg, cv2.MORPH_DILATE, st)
st = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5,5))
binaryImg = cv2.morphologyEx(binaryImg, cv2.MORPH_DILATE, st)

circles = cv2.HoughCircles(binaryImg, cv2.HOUGH_GRADIENT, 1, 20, param1 = 40,
                           param2 = 16, minRadius = 60, maxRadius = 150)

print(circles.shape)

circles = circles[0]
print(circles.shape)

for circle in circles:
    coor = (int(circle[0]), int(circle[1]))
    cv2.circle(origImg, coor, int(circle[2]), (0,0,255), 5)


cv2.imshow("binaryCombined",binaryImg)
cv2.imshow("new",origImg)

cv2.waitKey(30000)